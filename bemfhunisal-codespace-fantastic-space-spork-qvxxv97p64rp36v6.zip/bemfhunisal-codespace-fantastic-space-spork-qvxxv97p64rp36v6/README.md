# Website BEM FH UNISAL — Kabinet Abisatya

Website resmi Badan Eksekutif Mahasiswa Fakultas Hukum Universitas Sali Al-Aitaam Bandung.

**Fitur utama:** situs publik bilingual (Indonesia/Inggris), berita, agenda, profil dan sejarah, kabinet dan arsip per periode, program kerja, galeri, pendaftaran anggota, serta layanan pengaduan rahasia/anonim dengan kode pelacakan. Konten dikelola melalui panel admin (`/admin`) dengan peran superadmin dan satgas. Integrasi Google Sheets dan Google Calendar tersedia untuk fitur terkait.

**Teknologi:** Python, FastAPI, MongoDB (Motor), React 19, Vite, TypeScript, dan Tailwind CSS v4.

## Prasyarat

- Python dan pip
- Node.js dan Yarn Classic (lockfile proyek menggunakan Yarn v1)
- MongoDB yang berjalan dan dapat diakses melalui `MONGO_URL` (contoh: `mongodb://localhost:27017`)

## Menjalankan secara lokal

Jalankan backend dan frontend di dua terminal terpisah dari direktori root proyek.

### 1. Backend

Pastikan MongoDB sudah berjalan. Buat file konfigurasi lokal satu kali, lalu isi `backend/.env` sesuai lingkungan Anda. Minimal, atur `MONGO_URL` dan `ADMIN_INITIAL_PASSWORD`.

```bash
# Dari direktori root proyek
cp -n backend/.env.example backend/.env
cd backend
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn server:app --host 127.0.0.1 --port 8001 --reload
```

Di Windows PowerShell, aktifkan virtual environment dengan `.venv\Scripts\Activate.ps1`.

### 2. Frontend

```bash
# Dari direktori root proyek, di terminal kedua
cd frontend
yarn install --frozen-lockfile
yarn dev
```

Buka frontend di [http://localhost:3000](http://localhost:3000). Vite meneruskan permintaan `/api` ke backend di port `8001`. Untuk memeriksa build produksi, jalankan `yarn build` dari direktori `frontend`.

Akun superadmin awal dibuat saat backend berjalan jika akun tersebut belum ada. Isi `ADMIN_INITIAL_PASSWORD` dengan password kuat minimal 12 karakter sebelum startup; backend menolak membuat akun awal jika password tidak disetel. Akun yang sudah ada tidak diubah otomatis.

## Keamanan produksi

- Untuk database baru, isi `ADMIN_INITIAL_PASSWORD` dengan password kuat minimal 12 karakter sebelum menjalankan backend. Akun yang sudah ada tidak diubah otomatis.
- Atur `CORS_ORIGINS` ke daftar origin frontend yang tepat (tanpa wildcard), misalnya `https://bem.example.id`. Wildcard diabaikan dan akses fallback dibatasi ke origin localhost.
- Sajikan website melalui HTTPS dan atur `COOKIE_SECURE=true`, termasuk bila TLS dihentikan di reverse proxy. Cookie admin memakai `HttpOnly` dan `SameSite=Lax`; endpoint admin memeriksa origin.
- Batasi akses MongoDB dan rahasia integrasi di lingkungan deployment. Di belakang reverse proxy, percayai header IP hanya dari proxy tepercaya yang dikonfigurasi pada server ASGI.

Dokumentasi fitur, model data, dan endpoint API tersedia di [memory/SPEC.md](memory/SPEC.md). Konfigurasi integrasi opsional (email, Google Sheets, dan Google Calendar) dijelaskan di [backend/.env.example](backend/.env.example).
